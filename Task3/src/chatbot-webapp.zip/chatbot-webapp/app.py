from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# 간단한 챗봇 응답 함수
def get_bot_response(user_input):
  if '안녕' in user_input:
    return '안녕하세요! 무엇을 도와드릴까요?'
  elif '이름' in user_input:
    return '저는 챗봇입니다.'
  elif '날씨' in user_input:
    return '오늘의 날씨는 맑음입니다.'
  else:
    return '죄송해요, 이해하지 못했어요.'

@app.route('/')
def index():
  return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
  user_input = request.json.get('message')
  bot_response = get_bot_response(user_input)
  return jsonify({'response': bot_response})

if __name__ == '__main__':
  app.run(debug=True)